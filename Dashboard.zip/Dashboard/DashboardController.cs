﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WEBLINK_CRM.Repositories;
using WLSPL_ERP_CRM.Models;

namespace WEBLINK_CRM.Controllers
{
    [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly IDashboardRepo _repo;

        public DashboardController(IDashboardRepo repo)
        {
            _repo = repo;
        }

        public ActionResult Index()
        {
            var allEmployees = _repo.GetAllEmployees();

            var salesEmployees = allEmployees
                .Where(e => e.Role == "Sales" || e.Role == "SubAdmin")
                .ToList();

            var empCodes = salesEmployees.Select(e => e.EmpCode).ToList();

            var clientTotals = _repo.GetClientTotals();
            var meetingTotals = _repo.GetMeetingTotals(empCodes);
            var companiesToday = _repo.GetCompanyDetailsToday();

            var cards = new List<EmployeeDashboardCard>();
            foreach (var emp in salesEmployees)
            {
                var card = new EmployeeDashboardCard
                {
                    Name = emp.Name,
                    EmpCode = emp.EmpCode
                };
                if (clientTotals.TryGetValue(emp.EmpCode, out var clients))
                {
                    card.TotalClients = clients.Total;
                    card.PaidClients = clients.Paid;
                    card.UnpaidClients = clients.Unpaid;
                }
                if (meetingTotals.TryGetValue(emp.EmpCode, out var meetings))
                {
                    card.FreshMeetings = meetings.Fresh;
                    card.FollowupMeetings = meetings.Followup;
                    card.ServiceMeetings = meetings.Service;
                }
                if (companiesToday.TryGetValue(emp.EmpCode, out var companies))
                {
                    card.CompaniesToday = companies;
                }
                cards.Add(card);
            }

            var model = new DashboardViewModel
            {
                Employees = cards
            };

            foreach (var emp in allEmployees)
            {
                if (clientTotals.TryGetValue(emp.EmpCode, out var clients))
                {
                    emp.TotalClients = clients.Total;
                    emp.PaidClients = clients.Paid;
                    emp.UnpaidClients = clients.Unpaid;
                }
                if (meetingTotals.TryGetValue(emp.EmpCode, out var meetings))
                {
                    emp.FreshMeetings = meetings.Fresh;
                    emp.FollowupMeetings = meetings.Followup;
                    emp.ServiceMeetings = meetings.Service;
                }
                if (companiesToday.TryGetValue(emp.EmpCode, out var companies))
                {
                    emp.CompaniesToday = companies.Count;
                }
            }

            model.EmployeeTree = EmployeeNode.BuildTree(allEmployees);

            return View(model);
        }

        [HttpGet]
        public JsonResult GetClientStats(string empCode)
        {
            var stats = _repo.GetClientTotalsForEmployee(empCode);
            return Json(new { total = stats.Total, paid = stats.Paid, unpaid = stats.Unpaid });
        }
    }
}