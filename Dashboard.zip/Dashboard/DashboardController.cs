﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WEBLINK_CRM.Repositories;
using WLSPL_ERP_CRM.Models;
using System.Security.Claims;

namespace WEBLINK_CRM.Controllers
{
    [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly IDashboardRepo _repo;
        public DashboardController(IDashboardRepo repo)
        {
            _repo = repo;
        }
        public ActionResult Index()
        {
            var allEmployees = _repo.GetAllEmployees();

            if (allEmployees == null || allEmployees.Count == 0)
                return View(new List<EmployeeNode>());

            SetOrgRoles(allEmployees);

            var currentEmpCode = HttpContext.Session.GetString("EmpCode");

            if (string.IsNullOrWhiteSpace(currentEmpCode))
                return View(new List<EmployeeNode>());

            var currentUser = allEmployees.FirstOrDefault(e =>
                string.Equals(
                    e.EmpCode?.Trim(),
                    currentEmpCode.Trim(),
                    StringComparison.OrdinalIgnoreCase));

            if (currentUser == null)
                return View(new List<EmployeeNode>());

            List<EmployeeNode> tree;

            switch (currentUser.OrgRole)
            {
                case "Admin":
                    tree = BuildAdminTree(allEmployees, currentUser);
                    break;

                case "Sub Admin":
                    tree = BuildSubAdminTree(allEmployees, currentUser);
                    break;

                case "Sales Manager":
                    tree = BuildManagerTree(allEmployees, currentUser);
                    break;

                case "Sales TL":
                    tree = BuildTeamLeadTree(allEmployees, currentUser);
                    break;

                case "Sales Executive":
                    tree = BuildExecutiveTree(allEmployees, currentUser);
                    break;

                default:
                    tree = BuildSelfOnlyTree(currentUser);
                    break;
            }

            return View(tree);
        }

        private static void SetOrgRoles(List<EmployeeNode> employees)
        {
            var admin = employees.FirstOrDefault(e =>
                string.Equals(e.EmpCode, "WLSPL/01", StringComparison.OrdinalIgnoreCase));

            foreach (var employee in employees)
            {
                if (string.Equals(employee.Role, "Admin", StringComparison.OrdinalIgnoreCase))
                {
                    employee.OrgRole =
                        string.Equals(employee.EmpCode, "WLSPL/01", StringComparison.OrdinalIgnoreCase)
                            ? "Admin"
                            : "Sub Admin";

                    continue;
                }

                if (!string.Equals(employee.Role, "Sales", StringComparison.OrdinalIgnoreCase))
                {
                    employee.OrgRole = "Other";
                    continue;
                }

                if (string.Equals(employee.SalesTLManager, "1", StringComparison.OrdinalIgnoreCase))
                {
                    employee.OrgRole = "Sales TL";
                    continue;
                }

                var hasChildren = employees.Any(e =>
                    string.Equals(
                        e.ParentCode,
                        employee.EmpCode,
                        StringComparison.OrdinalIgnoreCase));

                if (hasChildren)
                {
                    employee.OrgRole = "Sales Manager";
                }
                else
                {
                    employee.OrgRole = "Sales Executive";
                }
            }
        }

        private static List<EmployeeNode> BuildAdminTree(List<EmployeeNode> employees,EmployeeNode admin)
        {
            return BuildHierarchyTree(employees, admin.EmpCode, true);
        }

        private static List<EmployeeNode> BuildSubAdminTree(List<EmployeeNode> employees,EmployeeNode subAdmin)
        {
            return BuildHierarchyTree(employees, subAdmin.EmpCode, true);
        }

        private static List<EmployeeNode> BuildManagerTree(List<EmployeeNode> employees,EmployeeNode manager)
        {
            return BuildHierarchyTree(employees, manager.EmpCode, true);
        }

        private static List<EmployeeNode> BuildTeamLeadTree(List<EmployeeNode> employees,EmployeeNode teamLead)
        {
            var executives = employees
                .Where(e =>
                    string.Equals(
                        e.ParentCode?.Trim(),
                        teamLead.EmpCode?.Trim(),
                        StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(
                        e.OrgRole?.Trim(),
                        "Sales Executive",
                        StringComparison.OrdinalIgnoreCase))
                .ToList();

            teamLead.Children = executives;

            foreach (var executive in executives)
            {
                executive.Children = new List<EmployeeNode>();
            }

            return new List<EmployeeNode>
    {
        teamLead
    };
        }


        private static List<EmployeeNode> BuildExecutiveTree(List<EmployeeNode> employees, EmployeeNode executive)
        {
            var teamLead = employees.FirstOrDefault(e =>
                string.Equals(
                    e.EmpCode,
                    executive.ParentCode,
                    StringComparison.OrdinalIgnoreCase));

            if (teamLead == null)
                return BuildSelfOnlyTree(executive);

            var manager = employees.FirstOrDefault(e =>
                string.Equals(
                    e.EmpCode,
                    teamLead.ParentCode,
                    StringComparison.OrdinalIgnoreCase));

            executive.Children = new List<EmployeeNode>();

            teamLead.Children = new List<EmployeeNode>
            {
                executive
            };

            if (manager == null)
                return new List<EmployeeNode>
                {
                    teamLead
                };

            manager.Children = new List<EmployeeNode>
            {
                teamLead
            };

            return new List<EmployeeNode>
            {
                manager
            };
        }

        private static List<EmployeeNode> BuildSelfOnlyTree(EmployeeNode user)
        {
            user.Children = new List<EmployeeNode>();

            return new List<EmployeeNode>
            {
                user
            };
        }

        private static List<EmployeeNode> BuildHierarchyTree(List<EmployeeNode> employees,string rootEmpCode,bool includeRoot)
        {
            foreach (var employee in employees)
                employee.Children = new List<EmployeeNode>();

            var lookup = employees
                .Where(e => !string.IsNullOrWhiteSpace(e.EmpCode))
                .GroupBy(e => e.EmpCode.Trim(), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    g => g.Key,
                    g => g.First(),
                    StringComparer.OrdinalIgnoreCase);

            foreach (var employee in employees)
            {
                if (string.IsNullOrWhiteSpace(employee.ParentCode))
                    continue;

                if (string.Equals(
                    employee.EmpCode,
                    employee.ParentCode,
                    StringComparison.OrdinalIgnoreCase))
                    continue;

                if (lookup.TryGetValue(employee.ParentCode.Trim(), out var parent))
                    parent.Children.Add(employee);
            }

            if (!lookup.TryGetValue(rootEmpCode.Trim(), out var root))
                return new List<EmployeeNode>();

            return new List<EmployeeNode>
            {
                root
            };
        }
    }
}