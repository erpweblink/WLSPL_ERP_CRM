﻿namespace WLSPL_ERP_CRM.Models
{
    public class EmployeeDashboardCard
    {
        public string Name { get; set; }
        public string EmpCode { get; set; }
        public int TotalClients { get; set; }
        public int PaidClients { get; set; }
        public int UnpaidClients { get; set; }
        public int FreshMeetings { get; set; }
        public int FollowupMeetings { get; set; }
        public int ServiceMeetings { get; set; }
        public int TotalMeetings => FreshMeetings + FollowupMeetings + ServiceMeetings;
        public List<CompanyRegistration> CompaniesToday { get; set; } = new();
    }

    public class CompanyRegistration
    {
        public string CompanyCode { get; set; }
        public string CompanyName { get; set; }
        public string OwnerName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Area { get; set; }
        public string State { get; set; }
        public string GstNo { get; set; }
        public string RegisteredAt { get; set; }
    }

    public class DashboardViewModel
    {
        public DateTime Today { get; set; } = DateTime.Today;
        public List<EmployeeDashboardCard> Employees { get; set; } = new();
        public int TotalEmployees => Employees.Count;
        public int TotalClients => Employees.Sum(e => e.TotalClients);
        public int TotalMeetingsThisMonth => Employees.Sum(e => e.TotalMeetings);
        public int TotalCompaniesToday => Employees.Sum(e => e.CompaniesToday.Count);

        public List<EmployeeNode> EmployeeTree { get; set; } = new();
    }

    public class EmployeeListItem
    {
        public string EmpCode { get; set; }
        public string Name { get; set; }
    }

    public class MeetingTotals
    {
        public int Fresh { get; set; }
        public int Followup { get; set; }
        public int Service { get; set; }
    }

    public class EmployeeNode
    {
        public string EmpCode { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public int Status { get; set; }

        public string ParentCode { get; set; }

        public string SalesTLManager { get; set; }

        public List<EmployeeNode> Children { get; set; } = new List<EmployeeNode>();

        public int TotalClients { get; set; }
        public int PaidClients { get; set; }
        public int UnpaidClients { get; set; }

        public int FreshMeetings { get; set; }
        public int FollowupMeetings { get; set; }
        public int ServiceMeetings { get; set; }

        public int TotalMeetings =>
            FreshMeetings + FollowupMeetings + ServiceMeetings;

        public int CompaniesToday { get; set; }

        public int CountDescendants()
        {
            int count = 0;
            foreach (var child in Children)
            {
                count += 1 + child.CountDescendants();
            }
            return count;
        }

        public static List<EmployeeNode> BuildTree(List<EmployeeNode> flatList)
        {
            var roots = new List<EmployeeNode>();

            if (flatList == null || flatList.Count == 0)
                return roots;

            var byCode = flatList
                .Where(e => !string.IsNullOrWhiteSpace(e.EmpCode))
                .GroupBy(e => e.EmpCode, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            foreach (var emp in byCode.Values)
            {
                emp.Children = new List<EmployeeNode>();
            }

            // Iterate flatList directly (not byCode.Values) to preserve ORDER BY id ASC order
            foreach (var emp in flatList)
            {
                if (!byCode.ContainsKey(emp.EmpCode))
                    continue; // duplicate EmpCode that lost out in GroupBy — skip

                var parentCode = emp.ParentCode;

                if (string.IsNullOrWhiteSpace(parentCode))
                {
                    continue; // no manager assigned — skip entirely, per your earlier decision
                }

                bool isSelfReferencingRoot =
                    parentCode.Equals(emp.EmpCode, StringComparison.OrdinalIgnoreCase);

                if (isSelfReferencingRoot)
                {
                    roots.Add(emp); // e.g. WLSPL/01, whose TL_Manager points to itself
                }
                else if (!byCode.ContainsKey(parentCode))
                {
                    roots.Add(emp); // manager code not found in active set — surfaced as root rather than lost
                }
                else
                {
                    byCode[parentCode].Children.Add(emp);
                }
            }

            return roots;
        }
    }

    public class ClientTotals
    {
        public int Total { get; set; }
        public int Paid { get; set; }
        public int Unpaid { get; set; }
    }
}
