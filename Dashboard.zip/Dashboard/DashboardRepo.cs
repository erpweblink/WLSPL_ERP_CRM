using Microsoft.Data.SqlClient;
using System.Data;
using WLSPL_ERP_CRM.Models;

namespace WEBLINK_CRM.Repositories
{
    public class DashboardRepo : IDashboardRepo
    {
        private readonly string _connectionString;

        public DashboardRepo(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Conn_Stringg")
                ?? throw new Exception("Connection string 'Conn_Stringg' not found.");
        }

        public Dictionary<string, ClientTotals> GetClientTotals()
        {
            var result = new Dictionary<string, ClientTotals>();
            const string sql = @"
                SELECT
                    sessionname AS EmpCode,
                    COUNT(*) AS TotalClients,
                    SUM(CASE WHEN LOWER(type) = 'paid'   THEN 1 ELSE 0 END) AS PaidClients,
                    SUM(CASE WHEN LOWER(type) = 'unpaid' THEN 1 ELSE 0 END) AS UnpaidClients
                FROM [Company]
                WHERE status = 1
                GROUP BY sessionname";

            using var con = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, con);
            con.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result[reader["EmpCode"].ToString()] = new ClientTotals
                {
                    Total = Convert.ToInt32(reader["TotalClients"]),
                    Paid = Convert.ToInt32(reader["PaidClients"]),
                    Unpaid = Convert.ToInt32(reader["UnpaidClients"])
                };
            }
            return result;
        }

        public Dictionary<string, MeetingTotals> GetMeetingTotals(List<string> empCodes)
        {
            var result = new Dictionary<string, MeetingTotals>();
            if (empCodes == null || empCodes.Count == 0) return result;

            var paramNames = empCodes.Select((_, i) => "@emp" + i).ToList();
            var sql = $@"
                SELECT
                    name AS EmpCode,
                    SUM(CASE WHEN Type = 'Fresh'     THEN 1 ELSE 0 END) AS FreshMeetings,
                    SUM(CASE WHEN Type = 'Follow-up' THEN 1 ELSE 0 END) AS FollowupMeetings,
                    SUM(CASE WHEN Type = 'Services'  THEN 1 ELSE 0 END) AS ServiceMeetings
                FROM stswlspl.VW_FollowUpRpt
                WHERE Updatefor = 'Meeting'
                    AND commentdatetime >= DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)
                    AND commentdatetime <  DATEADD(month, DATEDIFF(month, 0, GETDATE()) + 1, 0)
                    AND name IN ({string.Join(",", paramNames)})
                GROUP BY name";

            using var con = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, con);
            for (int i = 0; i < empCodes.Count; i++)
                cmd.Parameters.AddWithValue(paramNames[i], empCodes[i]);

            con.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result[reader["EmpCode"].ToString()] = new MeetingTotals
                {
                    Fresh = Convert.ToInt32(reader["FreshMeetings"]),
                    Followup = Convert.ToInt32(reader["FollowupMeetings"]),
                    Service = Convert.ToInt32(reader["ServiceMeetings"])
                };
            }
            return result;
        }

        public Dictionary<string, List<CompanyRegistration>> GetCompanyDetailsToday()
        {
            var result = new Dictionary<string, List<CompanyRegistration>>();
            const string sql = @"
                SELECT
                    C.BDE     AS EmpCode,
                    C.ccode   AS CompanyCode,
                    C.cname   AS CompanyName,
                    C.oname   AS OwnerName,
                    C.mobile  AS Mobile,
                    C.email   AS Email,
                    C.area    AS Area,
                    C.State   AS State,
                    C.gstno   AS GstNo,
                    C.regdate AS RegisteredAt
                FROM Company C
                WHERE ISNULL(C.IsDeleted,0) = 0
                    AND CAST(C.regdate AS DATE) = CAST(GETDATE() AS DATE)
                ORDER BY C.regdate DESC";

            using var con = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, con);
            con.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var empCode = reader["EmpCode"].ToString();
                if (!result.ContainsKey(empCode))
                    result[empCode] = new List<CompanyRegistration>();

                result[empCode].Add(new CompanyRegistration
                {
                    CompanyCode = reader["CompanyCode"].ToString(),
                    CompanyName = reader["CompanyName"].ToString(),
                    OwnerName = reader["OwnerName"].ToString(),
                    Mobile = reader["Mobile"].ToString(),
                    Email = reader["Email"].ToString(),
                    Area = reader["Area"].ToString(),
                    State = reader["State"].ToString(),
                    GstNo = reader["GstNo"].ToString(),
                    RegisteredAt = Convert.ToDateTime(reader["RegisteredAt"]).ToString("dd MMM yyyy HH:mm")
                });
            }
            return result;
        }

        public List<EmployeeNode> GetAllEmployees()
        {
            var list = new List<EmployeeNode>();
            const string sql = @"
                    SELECT
                        empcode,
                        name,
                        role,
                        status,
                        TL_Manager        AS ParentCode,
                        Sales_TL_Manager  AS SalesTLManager
                    FROM employees
                    WHERE isdeleted = 0 AND status = 1 AND TL_Manager IS NOT NULL
                    ORDER BY id ASC";

            using var con = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, con);
            con.Open();
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new EmployeeNode
                {
                    EmpCode = reader["empcode"].ToString(),
                    Name = reader["name"].ToString(),
                    Role = reader["role"].ToString(),
                    Status = reader["status"] == DBNull.Value ? 0 : Convert.ToInt32(reader["status"]),
                    ParentCode = reader["ParentCode"] == DBNull.Value ? null : reader["ParentCode"].ToString(),
                    SalesTLManager = reader["SalesTLManager"] == DBNull.Value ? null : reader["SalesTLManager"].ToString()
                });
            }
            return list;
        }

        public ClientTotals GetClientTotalsForEmployee(string empCode)
        {
            const string sql = @"
                SELECT
                    COUNT(*) AS TotalClients,
                    SUM(CASE WHEN LOWER(type) = 'paid'   THEN 1 ELSE 0 END) AS PaidClients,
                    SUM(CASE WHEN LOWER(type) = 'unpaid' THEN 1 ELSE 0 END) AS UnpaidClients
                FROM [Company]
                WHERE status = 1 AND sessionname = @empCode
                GROUP BY sessionname";

            using var con = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@empCode", (object)empCode ?? DBNull.Value);

            con.Open();
            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new ClientTotals
                {
                    Total = Convert.ToInt32(reader["TotalClients"]),
                    Paid = Convert.ToInt32(reader["PaidClients"]),
                    Unpaid = Convert.ToInt32(reader["UnpaidClients"])
                };
            }

            // no clients found for this empcode - return zeros rather than null
            return new ClientTotals { Total = 0, Paid = 0, Unpaid = 0 };
        }
    }
}