using WLSPL_ERP_CRM.Models;

namespace WEBLINK_CRM.Repositories
{
    public interface IDashboardRepo
    {
        Dictionary<string, ClientTotals> GetClientTotals();
        Dictionary<string, MeetingTotals> GetMeetingTotals(List<string> empCodes);
        Dictionary<string, List<CompanyRegistration>> GetCompanyDetailsToday();
        List<EmployeeNode> GetAllEmployees();
        ClientTotals GetClientTotalsForEmployee(string empCode);
    }
}
